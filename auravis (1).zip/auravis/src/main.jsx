import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App.jsx';
import './styles/app.css';

createRoot(document.getElementById('root')).render(<App />);
